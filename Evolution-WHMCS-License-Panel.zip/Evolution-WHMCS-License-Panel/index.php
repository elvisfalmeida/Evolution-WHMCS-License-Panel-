<?php
// Página inicial simples, pode redirecionar ou exibir algo
header("Location: admin/admin_login.php");
exit;
