<?php
header("Content-Type: application/json");
require_once __DIR__ . '/../includes/db.php';

// Obtendo os parâmetros corretamente via JSON POST
$data = json_decode(file_get_contents("php://input"), true);

$licenseKey = $data['licenseKey'] ?? '';
$domain = $data['domain'] ?? '';
$ip = $data['ip'] ?? '';

if (empty($licenseKey) || empty($domain) || empty($ip)) {
    echo json_encode(["error" => "Parâmetros inválidos"], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Verifica a licença no banco de dados
$stmt = $pdo->prepare("SELECT * FROM licenses WHERE license_key = ? LIMIT 1");
$stmt->execute([$licenseKey]);
$license = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$license) {
    echo json_encode(["status" => "invalid", "message" => "Licença inexistente"], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Verifica se a licença está vinculada ao mesmo domínio/IP
if ($license['domain'] !== $domain || $license['ip'] !== $ip) {
    echo json_encode(["status" => "invalid", "message" => "Licença inválida para este domínio/IP"], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Verifica o status da licença
if ($license['status'] !== 'active') {
    echo json_encode(["status" => "inactive", "message" => "Licença suspensa ou expirada"], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// Verifica a data de expiração, se houver
if (!empty($license['expiration_date']) && $license['expiration_date'] !== '0000-00-00') {
    $today = date('Y-m-d');
    if ($today > $license['expiration_date']) {
        echo json_encode(["status" => "expired", "message" => "Licença expirada"], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }
}

// Se passou em todas as validações, a licença é válida
echo json_encode(["status" => "active", "message" => "Licença válida"], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
