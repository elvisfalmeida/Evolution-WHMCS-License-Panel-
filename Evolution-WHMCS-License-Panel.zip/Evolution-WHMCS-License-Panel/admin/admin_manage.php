<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

$pageTitle = "Gerenciar Administradores - Sistema de Licenças";
require_once 'admin_header.php'; // Cabeçalho com navbar e dark/light mode
require_once __DIR__ . '/../includes/db.php';

// Busca todos os admins para exibir na tabela
$stmt = $pdo->query("SELECT * FROM admins ORDER BY created_at DESC");
$admins = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<div class="row">
  <div class="col-12">
    <h4 class="mb-4">Administradores Cadastrados</h4>
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h5 class="mb-0">Lista de Administradores</h5>
      <a href="admin_register.php" class="btn btn-primary">Adicionar Novo</a>
    </div>
    <?php if (!$admins): ?>
      <div class="alert alert-info">Nenhum administrador cadastrado.</div>
    <?php else: ?>
      <div class="table-responsive">
        <table class="table table-striped align-middle">
          <thead class="table-light">
            <tr>
              <th>ID</th>
              <th>Usuário</th>
              <th>E-mail</th>
              <th>Criado em</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($admins as $admin): ?>
              <tr>
                <td><?php echo htmlspecialchars($admin['id']); ?></td>
                <td><?php echo htmlspecialchars($admin['username']); ?></td>
                <td><?php echo htmlspecialchars($admin['email']); ?></td>
                <td><?php echo htmlspecialchars($admin['created_at']); ?></td>
                <td>
                  <a href="admin_edit.php?id=<?php echo $admin['id']; ?>" class="btn btn-warning btn-sm">Editar</a>
                  <a href="admin_delete.php?id=<?php echo $admin['id']; ?>"
                     class="btn btn-danger btn-sm"
                     onclick="return confirm('Tem certeza que deseja excluir este administrador?');">Excluir</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
    <a href="admin_dashboard.php" class="btn btn-secondary mt-3">Voltar ao Dashboard</a>
  </div>
</div>
<?php require_once 'admin_footer.php'; ?>
