<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

$pageTitle = "Logs de Auditoria";
require_once 'admin_header.php';
require_once __DIR__ . '/../includes/db.php';

// Consulta com JOIN para exibir o username do admin
$stmt = $pdo->query("
    SELECT audit_logs.*, admins.username
    FROM audit_logs
    LEFT JOIN admins ON audit_logs.admin_id = admins.id
    ORDER BY audit_logs.created_at DESC
");
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="container">
  <h3 class="mb-4">Logs de Auditoria</h3>
  <?php if (!$logs): ?>
    <div class="alert alert-info">Nenhum log encontrado.</div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead class="table-light">
          <tr>
            <th>ID</th>
            <th>Admin</th>
            <th>Ação</th>
            <th>Detalhes</th>
            <th>Data/Hora</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($logs as $log): ?>
            <tr>
              <td><?= htmlspecialchars($log['id']); ?></td>
              <td><?= htmlspecialchars($log['username'] ?? 'Desconhecido'); ?></td>
              <td><?= htmlspecialchars($log['action']); ?></td>
              <td><?= htmlspecialchars($log['details'] ?? ''); ?></td>
              <td><?= htmlspecialchars($log['created_at']); ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
  <a href="admin_dashboard.php" class="btn btn-secondary mt-3">Voltar ao Dashboard</a>
</div>
<?php require_once 'admin_footer.php'; ?>
