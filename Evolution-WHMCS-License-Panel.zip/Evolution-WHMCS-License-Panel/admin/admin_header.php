<?php
// admin_header.php - Template de Cabeçalho com Bootstrap 5 e dark/light mode

if (session_status() === PHP_SESSION_NONE) {
    session_start();
} // Garante que a sessão está iniciada para verificar login

// Verifica se o admin está logado
$isLoggedIn = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo isset($pageTitle) ? $pageTitle : 'Painel Admin'; ?></title>
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Helvetica:300,400,500,700&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
      transition: background-color 0.3s, color 0.3s;
    }
    /* Light mode */
    body.light {
      background-color: #f8f9fa;
      color: #212529;
    }
    /* Dark mode */
    body.dark {
      background-color: #121212;
      color: #e0e0e0;
    }
    /* Navbar styles */
    .navbar-light {
      background-color: #ffffff;
      border-bottom: 1px solid #dee2e6;
    }
    .navbar-dark {
      background-color: #1f1f1f;
      border-bottom: 1px solid #343a40;
    }
    /* Footer */
    footer {
      padding: 1rem 0;
      text-align: center;
      border-top: 1px solid;
    }
    footer.light {
      background-color: #ffffff;
      border-color: #dee2e6;
      color: #212529;
    }
    footer.dark {
      background-color: #1f1f1f;
      border-color: #343a40;
      color: #b0b0b0;
    }
  </style>
</head>
<body class="light">
  <!-- Navbar -->
  <?php
    // Definimos a classe do navbar de acordo com o modo (light/dark) via JS depois
    // mas por padrão definimos como navbar-light
  ?>
  <nav id="navbar" class="navbar navbar-expand-lg navbar-light">
    <div class="container">
      <a class="navbar-brand" href="<?php echo $isLoggedIn ? 'admin_dashboard.php' : 'admin_login.php'; ?>">Painel Admin</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <?php if ($isLoggedIn): ?>
            <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="admin_manage.php">Administradores</a></li>
            <li class="nav-item"><a class="nav-link" href="change_password.php">Alterar Senha</a></li>
            <li class="nav-item"><a class="nav-link text-danger" href="admin_logout.php">Sair</a></li>
          <?php else: ?>
            <!-- Se não estiver logado, exiba apenas um link de login (opcional) -->
            <li class="nav-item"><a class="nav-link" href="admin_login.php">Login</a></li>
          <?php endif; ?>
          <!-- Botão de modo claro/escuro -->
          <li class="nav-item">
            <button id="toggleThemeBtn" class="btn btn-outline-secondary ms-2">Dark Mode</button>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="container my-4">
