<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}
$pageTitle = "Configurações do Sistema - Sistema de Licenças";
require_once 'admin_header.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $updatedKeys = [];
    foreach ($_POST as $key => $value) {
        $stmt = $pdo->prepare("UPDATE configurations SET config_value = ? WHERE config_key = ?");
        $stmt->execute([$value, $key]);
        $updatedKeys[] = $key;
    }
    $message = "Configurações atualizadas com sucesso.";
    $adminId = $_SESSION['admin_id'] ?? null;
    logAudit($adminId, "Atualização de Configurações", "Config keys atualizadas: " . implode(", ", $updatedKeys));
}

$stmt = $pdo->query("SELECT * FROM configurations ORDER BY config_key ASC");
$configs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="container">
    <h3 class="mb-4">Configurações do Sistema</h3>
    <?php if ($message): ?>
         <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <form method="post">
        <?php foreach ($configs as $config): ?>
            <div class="mb-3">
                <label class="form-label">
                  <strong><?php echo htmlspecialchars($config['config_key']); ?></strong>
                  <small class="text-muted"><?php echo htmlspecialchars($config['description']); ?></small>
                </label>
                <input type="text" class="form-control" name="<?php echo htmlspecialchars($config['config_key']); ?>" value="<?php echo htmlspecialchars($config['config_value']); ?>">
            </div>
        <?php endforeach; ?>
        <button type="submit" class="btn btn-primary">Salvar Configurações</button>
    </form>
    <a href="admin_dashboard.php" class="btn btn-secondary mt-3">Voltar ao Dashboard</a>
</div>
<?php require_once 'admin_footer.php'; ?>
