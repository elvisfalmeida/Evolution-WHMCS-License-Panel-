<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}
$pageTitle = "Resetar Licença - Sistema de Licenças";
require_once 'admin_header.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

$message = "";
// Consulta todas as licenças
$stmt = $pdo->query("SELECT id, license_key, domain, ip, status FROM licenses ORDER BY license_key ASC");
$licenses = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $licenseId = $_POST['license_id'] ?? "";
    if (empty($licenseId)) {
        $message = "Selecione uma licença para resetar.";
    } else {
        // Reseta os campos domain e ip da licença selecionada
        $stmt = $pdo->prepare("UPDATE licenses SET domain = '', ip = '' WHERE id = ?");
        if ($stmt->execute([$licenseId])) {
            $message = "Licença resetada com sucesso.";
            // Log de auditoria
            logAudit($_SESSION['admin_id'] ?? null, "Reset de Licença", "Licença resetada: ID " . $licenseId);
        } else {
            $message = "Erro ao resetar a licença.";
        }
    }
}
?>
<div class="container">
  <h3 class="mb-4">Resetar Licença</h3>
  <?php if ($message): ?>
    <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
  <?php endif; ?>
  <form method="post">
    <div class="mb-3">
      <label for="license_id" class="form-label"><strong>Selecione a Licença</strong></label>
      <select class="form-select" name="license_id" id="license_id" required>
        <option value="">-- Selecione --</option>
        <?php foreach ($licenses as $license): ?>
          <option value="<?php echo $license['id']; ?>">
            <?php echo htmlspecialchars($license['license_key']); ?> - 
            <?php echo htmlspecialchars($license['domain'] ?: 'Sem Domínio'); ?> / 
            <?php echo htmlspecialchars($license['ip'] ?: 'Sem IP'); ?> - 
            <?php echo htmlspecialchars(ucfirst($license['status'])); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <button type="submit" class="btn btn-warning">Resetar Licença</button>
  </form>
  <a href="admin_dashboard.php" class="btn btn-secondary mt-3">Voltar ao Dashboard</a>
</div>
<?php require_once 'admin_footer.php'; ?>
