<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}
$pageTitle = "Cadastrar Administrador - Sistema de Licenças";
require_once 'admin_header.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? "");
    $email = trim($_POST['email'] ?? "");
    $password = $_POST['password'] ?? "";
    $confirm_password = $_POST['confirm_password'] ?? "";
    
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $message = "Todos os campos são obrigatórios.";
    } elseif ($password !== $confirm_password) {
        $message = "A senha e a confirmação não coincidem.";
    } else {
        $complexityCheck = isPasswordComplex($password);
        if ($complexityCheck !== true) {
            $message = $complexityCheck;
        } else {
            $stmt = $pdo->prepare("SELECT id FROM admins WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetch()) {
                $message = "Usuário já existe.";
            } else {
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO admins (username, email, password) VALUES (?, ?, ?)");
                if ($stmt->execute([$username, $email, $hashed_password])) {
                    $adminId = $pdo->lastInsertId();
                    logAudit($adminId, "Cadastro de Administrador", "Novo admin cadastrado: $username");
                    $message = "Administrador cadastrado com sucesso.";
                } else {
                    $message = "Erro ao cadastrar o administrador.";
                }
            }
        }
    }
}
?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <?php if ($message): ?>
      <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <div class="card shadow-sm">
      <div class="card-body">
        <h4 class="card-title text-center mb-4">Cadastrar Administrador</h4>
        <form method="post">
          <div class="mb-3">
            <label for="username" class="form-label">Usuário</label>
            <input type="text" class="form-control" name="username" id="username" required>
          </div>
          <div class="mb-3">
            <label for="email" class="form-label">E-mail</label>
            <input type="email" class="form-control" name="email" id="email" required>
          </div>
          <div class="mb-3">
            <label for="password" class="form-label">Senha</label>
            <input type="password" class="form-control" name="password" id="password" required>
          </div>
          <div class="mb-3">
            <label for="confirm_password" class="form-label">Confirmar Senha</label>
            <input type="password" class="form-control" name="confirm_password" id="confirm_password" required>
          </div>
          <button type="submit" class="btn btn-primary w-100">Cadastrar</button>
        </form>
      </div>
    </div>
    <div class="text-center mt-3">
      <a href="admin_manage.php" class="btn btn-secondary">Voltar</a>
    </div>
  </div>
</div>
<?php require_once 'admin_footer.php'; ?>
