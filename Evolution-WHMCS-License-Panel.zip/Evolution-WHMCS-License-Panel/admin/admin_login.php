<?php
session_start();
if(isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true){
  header("Location: admin_dashboard.php");
  exit;
}
$pageTitle = "Admin Login - Sistema de Licenças";
require_once 'admin_header.php';
require_once __DIR__ . '/../includes/db.php';

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? "";
    $password = $_POST['password'] ?? "";

    $stmt = $pdo->prepare("SELECT id, username, password FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $admin['username'];
        // Armazena o ID do admin para uso nos logs
        $_SESSION['admin_id'] = $admin['id'];

        header("Location: admin_dashboard.php");
        exit;
    } else {
        $message = "Usuário ou senha inválidos.";
    }
}

?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <?php if($message): ?>
      <div class="alert alert-danger"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <div class="card shadow-sm">
      <div class="card-body">
        <h4 class="card-title text-center">Admin Login</h4>
        <form method="post" action="">
          <div class="mb-3">
            <label for="username" class="form-label">Usuário</label>
            <input type="text" class="form-control" id="username" name="username" required>
          </div>
          <div class="mb-3">
            <label for="password" class="form-label">Senha</label>
            <input type="password" class="form-control" id="password" name="password" required>
          </div>
          <button type="submit" class="btn btn-primary w-100">Entrar</button>
        </form>
        <div class="text-center mt-3">
          <a href="forgot_password.php">Esqueci minha senha</a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php require_once 'admin_footer.php'; ?>
