<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}
$pageTitle = "Editar Administrador - Sistema de Licenças";
require_once 'admin_header.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isset($_GET['id'])) {
    header("Location: admin_manage.php");
    exit;
}

$id = intval($_GET['id']);
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin) {
    die("Administrador não encontrado.");
}

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? "");
    $password = $_POST['password'] ?? "";
    $confirm_password = $_POST['confirm_password'] ?? "";
    
    if (empty($email)) {
        $message = "O e-mail é obrigatório.";
    } elseif (!empty($password) || !empty($confirm_password)) {
        if ($password !== $confirm_password) {
            $message = "A senha e a confirmação não coincidem.";
        } else {
            $complexityCheck = isPasswordComplex($password);
            if ($complexityCheck !== true) {
                $message = $complexityCheck;
            } else {
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                $stmtUpdate = $pdo->prepare("UPDATE admins SET email = ?, password = ? WHERE id = ?");
                $result = $stmtUpdate->execute([$email, $hashed_password, $id]);
                if ($result) {
                    $message = "Administrador atualizado com sucesso.";
                    logAudit($admin['id'], "Edição de Administrador", "Admin atualizado: " . $admin['username']);
                    $stmt->execute([$id]);
                    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
                } else {
                    $message = "Erro ao atualizar o administrador.";
                }
            }
        }
    } else {
        $stmtUpdate = $pdo->prepare("UPDATE admins SET email = ? WHERE id = ?");
        $result = $stmtUpdate->execute([$email, $id]);
        if ($result) {
            $message = "Administrador atualizado com sucesso.";
            logAudit($admin['id'], "Edição de Administrador", "Admin atualizado: " . $admin['username']);
            $stmt->execute([$id]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            $message = "Erro ao atualizar o administrador.";
        }
    }
}
?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <?php if ($message): ?>
      <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <div class="card shadow-sm">
      <div class="card-body">
        <h4 class="card-title text-center mb-4">Editar Administrador</h4>
        <form method="post">
          <div class="mb-3">
            <label class="form-label">Usuário</label>
            <input type="text" class="form-control" value="<?php echo htmlspecialchars($admin['username']); ?>" disabled>
          </div>
          <div class="mb-3">
            <label for="email" class="form-label">E-mail</label>
            <input type="email" class="form-control" name="email" id="email" value="<?php echo htmlspecialchars($admin['email']); ?>" required>
          </div>
          <p class="text-muted">Para alterar a senha, preencha os campos abaixo (senão deixe em branco):</p>
          <div class="mb-3">
            <label for="password" class="form-label">Nova Senha</label>
            <input type="password" class="form-control" name="password" id="password">
          </div>
          <div class="mb-3">
            <label for="confirm_password" class="form-label">Confirmar Nova Senha</label>
            <input type="password" class="form-control" name="confirm_password" id="confirm_password">
          </div>
          <button type="submit" class="btn btn-primary w-100">Atualizar</button>
        </form>
      </div>
    </div>
    <div class="text-center mt-3">
      <a href="admin_manage.php" class="btn btn-secondary">Voltar</a>
    </div>
  </div>
</div>
<?php require_once 'admin_footer.php'; ?>
