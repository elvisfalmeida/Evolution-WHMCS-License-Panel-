<?php
// admin_footer.php - Template de Rodapé com Bootstrap 5 e dark/light mode
?>
  </div> <!-- Fecha container principal -->
  <footer id="footer" class="light">
    <div class="container">
      &copy; <?php echo date('Y'); ?> Sistema de Licenças - Todos os direitos reservados.
    </div>
  </footer>
  <!-- Bootstrap 5 JS Bundle -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Dark/Light Mode Toggle
    const toggleBtn = document.getElementById('toggleThemeBtn');
    const body = document.body;
    const navbar = document.getElementById('navbar');
    const footer = document.getElementById('footer');

    function setTheme(theme) {
      if(theme === 'dark'){
        body.classList.remove('light');
        body.classList.add('dark');
        navbar.classList.remove('navbar-light');
        navbar.classList.add('navbar-dark');
        footer.classList.remove('light');
        footer.classList.add('dark');
        toggleBtn.textContent = 'Light Mode';
      } else {
        body.classList.remove('dark');
        body.classList.add('light');
        navbar.classList.remove('navbar-dark');
        navbar.classList.add('navbar-light');
        footer.classList.remove('dark');
        footer.classList.add('light');
        toggleBtn.textContent = 'Dark Mode';
      }
      localStorage.setItem('theme', theme);
    }

    // Verifica tema salvo no localStorage
    const savedTheme = localStorage.getItem('theme') || 'light';
    setTheme(savedTheme);

    toggleBtn.addEventListener('click', () => {
      const currentTheme = body.classList.contains('dark') ? 'dark' : 'light';
      setTheme(currentTheme === 'dark' ? 'light' : 'dark');
    });
  </script>
</body>
</html>
