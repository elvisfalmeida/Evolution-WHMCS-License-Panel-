<?php
session_start();
$pageTitle = "Redefinir Senha - Sistema de Licenças";
require_once 'admin_header.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

date_default_timezone_set('America/Sao_Paulo');

if(!isset($_GET['token'])){
    die("Token inválido.");
}
$token = $_GET['token'];

$stmt = $pdo->prepare("SELECT * FROM admin_password_resets WHERE token = ?");
$stmt->execute([$token]);
$reset = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$reset){
    die("Token inválido ou expirado.");
}

if(strtotime($reset['created_at']) < (time() - 7200)){
    die("Token expirado.");
}

$message = "";
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $new_password = $_POST['new_password'] ?? "";
    $confirm_password = $_POST['confirm_password'] ?? "";
    if(empty($new_password) || empty($confirm_password)){
        $message = "Por favor, preencha todos os campos.";
    } elseif($new_password !== $confirm_password){
        $message = "As senhas não coincidem.";
    } else {
        $complexityCheck = isPasswordComplex($new_password);
        if($complexityCheck !== true){
            $message = $complexityCheck;
        } else {
            $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE admins SET password = ? WHERE id = ?");
            if($stmt->execute([$hashed_password, $reset['admin_id']])){
                $stmt = $pdo->prepare("DELETE FROM admin_password_resets WHERE token = ?");
                $stmt->execute([$token]);
                $message = "Senha redefinida com sucesso. Você pode <a href='admin_login.php'>fazer login</a>.";
            } else {
                $message = "Erro ao atualizar a senha.";
            }
        }
    }
}
?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <?php if($message): ?>
      <div class="alert alert-info"><?php echo $message; ?></div>
    <?php endif; ?>
    <?php if(empty($message) || strpos($message, 'sucesso') === false): ?>
    <div class="card shadow-sm">
      <div class="card-body">
        <h4 class="card-title text-center">Redefinir Senha</h4>
        <form method="post">
          <div class="mb-3">
            <label for="new_password" class="form-label">Nova Senha</label>
            <input type="password" class="form-control" name="new_password" id="new_password" required>
          </div>
          <div class="mb-3">
            <label for="confirm_password" class="form-label">Confirmar Nova Senha</label>
            <input type="password" class="form-control" name="confirm_password" id="confirm_password" required>
          </div>
          <button type="submit" class="btn btn-success w-100">Redefinir Senha</button>
        </form>
      </div>
    </div>
    <?php endif; ?>
    <div class="text-center mt-3">
      <a href="admin_login.php" class="btn btn-secondary">Voltar ao Login</a>
    </div>
  </div>
</div>
<?php require_once 'admin_footer.php'; ?>
