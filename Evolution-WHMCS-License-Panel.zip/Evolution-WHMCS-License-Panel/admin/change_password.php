<?php
session_start();
if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true){
  header("Location: admin_login.php");
  exit;
}
$pageTitle = "Alterar Senha - Sistema de Licenças";
require_once 'admin_header.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

$message = "";
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $current_password = $_POST['current_password'] ?? "";
    $new_password = $_POST['new_password'] ?? "";
    $confirm_password = $_POST['confirm_password'] ?? "";
    
    if(empty($current_password) || empty($new_password) || empty($confirm_password)){
        $message = "Todos os campos são obrigatórios.";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
        $stmt->execute([$_SESSION['admin_username']]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        if($admin && password_verify($current_password, $admin['password'])){
            if($new_password !== $confirm_password){
                $message = "As senhas não coincidem.";
            } else {
                $complexityCheck = isPasswordComplex($new_password);
                if($complexityCheck !== true){
                    $message = $complexityCheck;
                } else {
                    $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
                    $stmt = $pdo->prepare("UPDATE admins SET password = ? WHERE username = ?");
                    if($stmt->execute([$hashed_password, $_SESSION['admin_username']])){
                        $message = "Senha alterada com sucesso.";
                    } else {
                        $message = "Erro ao atualizar a senha.";
                    }
                }
            }
        } else {
            $message = "Senha atual incorreta.";
        }
    }
}
?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <?php if($message): ?>
      <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <div class="card shadow-sm">
      <div class="card-body">
        <h4 class="card-title text-center mb-4">Alterar Senha</h4>
        <form method="post">
          <div class="mb-3">
            <label for="current_password" class="form-label">Senha Atual</label>
            <input type="password" class="form-control" name="current_password" id="current_password" required>
          </div>
          <div class="mb-3">
            <label for="new_password" class="form-label">Nova Senha</label>
            <input type="password" class="form-control" name="new_password" id="new_password" required>
          </div>
          <div class="mb-3">
            <label for="confirm_password" class="form-label">Confirmar Nova Senha</label>
            <input type="password" class="form-control" name="confirm_password" id="confirm_password" required>
          </div>
          <button type="submit" class="btn btn-primary w-100">Alterar Senha</button>
        </form>
      </div>
    </div>
    <div class="text-center mt-3">
      <a href="admin_dashboard.php" class="btn btn-secondary">Voltar ao Dashboard</a>
    </div>
  </div>
</div>
<?php require_once 'admin_footer.php'; ?>
