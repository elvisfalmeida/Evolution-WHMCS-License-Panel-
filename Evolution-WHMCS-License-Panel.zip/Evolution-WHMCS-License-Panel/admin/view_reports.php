<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

require_once __DIR__ . '/../includes/db.php';

$stmt = $pdo->query("SELECT * FROM licenses ORDER BY created_at DESC");
$licenses = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Relatórios de Licenças - Sistema de Licenças</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Relatórios de Licenças</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Chave de Licença</th>
                <th>Domínio</th>
                <th>IP</th>
                <th>Status</th>
                <th>Expira em</th>
                <th>Criado em</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($licenses as $license): ?>
                <tr>
                    <td><?php echo htmlspecialchars($license['id']); ?></td>
                    <td><?php echo htmlspecialchars($license['license_key']); ?></td>
                    <td><?php echo htmlspecialchars($license['domain']); ?></td>
                    <td><?php echo htmlspecialchars($license['ip']); ?></td>
                    <td><?php echo htmlspecialchars($license['status']); ?></td>
                    <td><?php echo htmlspecialchars($license['expiration_date']); ?></td>
                    <td><?php echo htmlspecialchars($license['created_at']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <a href="admin_dashboard.php" class="btn btn-secondary">Voltar ao Dashboard</a>
</div>
</body>
</html>
