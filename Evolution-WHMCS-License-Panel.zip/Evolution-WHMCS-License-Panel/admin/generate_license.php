<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

require_once __DIR__ . '/../includes/db.php';

function generateLicenseKey($length = 20) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $licenseKey = 'EWH-';
    for ($i = 0; $i < $length; $i++) {
        $licenseKey .= $characters[random_int(0, strlen($characters) - 1)];
    }
    return $licenseKey;
}

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $domain = $_POST['domain'] ?? "";
    $ip = $_POST['ip'] ?? "";
    $expiration = $_POST['expiration'] ?? ""; // Data de expiração
    if (empty($domain) || empty($ip)) {
        $message = "Por favor, preencha o domínio e o IP.";
    } else {
        $licenseKey = generateLicenseKey();
        if (!empty($expiration)) {
            // Valida se é uma data válida (opcional)
            // $expiration = date('Y-m-d', strtotime($expiration));
        } else {
            $expiration = null;
        }

        $stmt = $pdo->prepare("INSERT INTO licenses (license_key, domain, ip, status, expiration_date) VALUES (?, ?, ?, 'active', ?)");
        if ($stmt->execute([$licenseKey, $domain, $ip, $expiration])) {
            $message = "Licença gerada com sucesso: " . $licenseKey;
        } else {
            $message = "Erro ao gerar a licença.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Gerar Licença - Sistema de Licenças</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Gerar Nova Licença</h2>
    <?php if ($message): ?>
        <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <form method="post">
        <div class="form-group">
            <label for="domain">Domínio (Ex: example.com)</label>
            <input type="text" class="form-control" name="domain" id="domain" required>
        </div>
        <div class="form-group">
            <label for="ip">IP (Ex: 192.168.0.1)</label>
            <input type="text" class="form-control" name="ip" id="ip" required>
        </div>
        <div class="form-group">
            <label for="expiration">Data de Expiração (opcional)</label>
            <input type="date" class="form-control" name="expiration" id="expiration">
        </div>
        <button type="submit" class="btn btn-primary">Gerar Licença</button>
    </form>
    <a href="admin_dashboard.php" class="btn btn-secondary mt-3">Voltar ao Dashboard</a>
</div>
</body>
</html>
