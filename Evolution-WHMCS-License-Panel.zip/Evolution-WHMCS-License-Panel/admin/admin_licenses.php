<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

$pageTitle = "Gerenciar Licenças - Servidor de Licenciamento";
require_once 'admin_header.php'; // Cabeçalho com navbar e dark/light mode
require_once __DIR__ . '/../includes/db.php';

// Consulta as licenças diretamente da tabela licenses
$stmt = $pdo->query("SELECT * FROM licenses ORDER BY created_at DESC");
$licenses = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="container">
  <h3 class="mb-4">Lista de Licenças</h3>
  <?php if (!$licenses): ?>
    <div class="alert alert-info">Nenhuma licença encontrada.</div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead class="table-light">
          <tr>
            <th>ID</th>
            <th>Chave</th>
            <th>Domínio</th>
            <th>IP</th>
            <th>Status</th>
            <th>Criado em</th>
            <th>Atualizado em</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($licenses as $lic): ?>
            <tr>
              <td><?= htmlspecialchars($lic['id']); ?></td>
              <td><?= htmlspecialchars($lic['license_key']); ?></td>
              <td><?= htmlspecialchars($lic['domain']); ?></td>
              <td><?= htmlspecialchars($lic['ip']); ?></td>
              <td><?= htmlspecialchars($lic['status']); ?></td>
              <td><?= htmlspecialchars($lic['created_at']); ?></td>
              <td><?= htmlspecialchars($lic['updated_at']); ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
  <a href="admin_dashboard.php" class="btn btn-secondary mt-3">Voltar ao Dashboard</a>
</div>
<?php require_once 'admin_footer.php'; ?>
