<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

$pageTitle = "Dashboard Admin - Sistema de Licenças";
require_once 'admin_header.php';
require_once __DIR__ . '/../includes/db.php';

// Consulta para obter as estatísticas de licenças
$stmt = $pdo->query("SELECT status, COUNT(*) AS total FROM licenses GROUP BY status");
$licenseStats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Inicializa os dados para cada status, garantindo que existam mesmo que seja zero
$data = [
    'active'    => 0,
    'expired'   => 0,
    'suspended' => 0,
];

foreach ($licenseStats as $row) {
    $status = $row['status'];
    $data[$status] = (int)$row['total'];
}

// Converte para JSON para uso no JavaScript (Chart.js)
$jsonData = json_encode($data);
?>

<div class="container">
  <div class="mb-4 text-center">
    <h2>Dashboard Admin</h2>
    <p>Bem-vindo, <strong><?php echo htmlspecialchars($_SESSION['admin_username']); ?></strong>!</p>
  </div>

  <!-- Primeira linha de cartões -->
  <div class="row g-4">
    <!-- Cartão Licenças -->
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Licenças</h5>
          <p class="card-text">Gerencie as licenças emitidas: edite, renove ou reset.</p>
          <a href="admin_license_manage.php" class="btn btn-info">Gerenciar Licenças</a>
        </div>
      </div>
    </div>
    <!-- Cartão Administradores -->
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Administradores</h5>
          <p class="card-text">Cadastre e edite administradores do sistema.</p>
          <a href="admin_register.php" class="btn btn-success">Cadastrar Administrador</a>
          <a href="admin_manage.php" class="btn btn-info">Gerenciar Administradores</a>
        </div>
      </div>
    </div>
    <!-- Cartão Configurações -->
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Configurações</h5>
          <p class="card-text">Ajuste as configurações do sistema (SMTP, etc.).</p>
          <a href="admin_config.php" class="btn btn-secondary">Configurações do Sistema</a>          
        </div>
      </div>
    </div>
  </div>

  <!-- Segunda linha de cartões -->
  <div class="row g-4 mt-4">
    <!-- Cartão Logs de Auditoria -->
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Logs de Auditoria</h5>
          <p class="card-text">Visualize o histórico de ações do sistema.</p>
          <a href="admin_logs.php" class="btn btn-dark">Ver Logs</a>
        </div>
      </div>
    </div>
    
    <!-- Cartão Estatísticas de Licenças (gráfico de barras) -->
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Estatísticas de Licenças</h5>
          <div style="width: 100%; height: 400px;">
            <canvas id="licenseChart"></canvas>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Opções de Ação -->
  <div class="text-center mt-4">
    <a href="change_password.php" class="btn btn-dark me-2">Alterar Senha</a>
    <a href="admin_logout.php" class="btn btn-danger">Sair</a>
  </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  // licenseData é o objeto com { active: X, expired: Y, suspended: Z }
  const licenseData = <?php echo $jsonData; ?>;
  const labels = ['Ativas', 'Expiradas', 'Suspensas'];
  const counts = [
    licenseData.active,
    licenseData.expired,
    licenseData.suspended
  ];

  const ctx = document.getElementById('licenseChart').getContext('2d');
  new Chart(ctx, {
    type: 'bar', // Gráfico de barras
    data: {
      labels: labels,
      datasets: [{
        label: 'Licenças',
        data: counts,
        backgroundColor: [
          'rgba(40, 167, 69, 0.7)',
          'rgba(220, 53, 69, 0.7)',
          'rgba(255, 193, 7, 0.7)'
        ],
        borderColor: [
          'rgba(40, 167, 69, 1)',
          'rgba(220, 53, 69, 1)',
          'rgba(255, 193, 7, 1)'
        ],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true
        }
      },
      plugins: {
        legend: {
          display: false
        },
        title: {
          display: true,
          text: 'Distribuição de Licenças'
        }
      }
    }
  });
</script>

<?php require_once 'admin_footer.php'; ?>
