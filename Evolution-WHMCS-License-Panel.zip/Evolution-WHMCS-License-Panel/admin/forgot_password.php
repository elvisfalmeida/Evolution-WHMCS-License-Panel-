<?php
session_start();
$pageTitle = "Recuperar Senha - Sistema de Licenças";
require_once 'admin_header.php';  // Layout com navbar, etc.
require_once __DIR__ . '/../includes/db.php';       // Conexão com o banco ($pdo)
require_once __DIR__ . '/../vendor/autoload.php';   // PHPMailer via Composer
require_once __DIR__ . '/../includes/functions.php';// getConfigValues, etc.

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? "");
    if (empty($email)) {
        $message = "Por favor, informe o e-mail.";
    } else {
        // Busca admin pelo e-mail
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin) {
            // Gera token único
            $token = bin2hex(random_bytes(16));
            // Insere na tabela de reset
            $stmtReset = $pdo->prepare("INSERT INTO admin_password_resets (admin_id, token) VALUES (?, ?)");
            if ($stmtReset->execute([$admin['id'], $token])) {
                // Monta o link de redefinição
                $resetLink = "https://license.meudominio.com.br/admin/admin_reset_password.php?token=" . urlencode($token);

                // Recupera as configurações do banco
                $keys = [
                    'smtp_host',
                    'smtp_username',
                    'smtp_password',
                    'smtp_port',
                    'smtp_from_address',
                    'smtp_from_name',
                    'smtp_encryption'
                ];
                $config = getConfigValues($keys);

                // Cria e configura o PHPMailer
                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    // Aplica as configurações SMTP do banco ou valores padrão
                    $mail->Host       = $config['smtp_host']       ?: '';
                    $mail->SMTPAuth   = true;
                    $mail->Username   = $config['smtp_username']   ?: '';
                    $mail->Password   = $config['smtp_password']   ?: '';
                    $mail->Port       = $config['smtp_port']       ?: ;
                    $mail->CharSet    = 'UTF-8';

                    // Definindo o tipo de criptografia (tls, ssl ou none)
                    $encryption = $config['smtp_encryption'] ?: 'tls';
                    if ($encryption === 'ssl') {
                        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                    } elseif ($encryption === 'none') {
                        $mail->SMTPSecure = '';
                    } else {
                        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    }

                    // Remetente (FROM)
                    $fromAddress = $config['smtp_from_address'] ?: 'noreply@meudominio.com.br';
                    $fromName    = $config['smtp_from_name']    ?: 'Suporte Licenciamento';
                    $mail->setFrom($fromAddress, $fromName);

                    // Destinatário
                    $mail->addAddress($email, $admin['username']);

                    // Conteúdo do e-mail
                    $mail->isHTML(true);
                    $mail->Subject = 'Recuperação de Senha - Sistema de Licenças';
                    $mail->Body    = "
                        <p>Olá, <strong>" . htmlspecialchars($admin['username']) . "</strong>.</p>
                        <p>Você solicitou a recuperação de sua senha. Para redefinir sua senha, clique no link abaixo:</p>
                        <p><a href='{$resetLink}'>{$resetLink}</a></p>
                        <p>Se você não solicitou a recuperação de senha, ignore este e-mail.</p>
                        <p>Atenciosamente,<br>Equipe de Suporte</p>
                    ";
                    $mail->AltBody = "Olá, " . $admin['username'] . ".\n\n"
                        . "Você solicitou a recuperação de sua senha. Utilize o seguinte link para redefinir sua senha:\n"
                        . $resetLink . "\n\n"
                        . "Se você não solicitou a recuperação de senha, ignore este e-mail.\n\n"
                        . "Atenciosamente,\nEquipe de Suporte";

                    // Tenta enviar
                    $mail->send();
                    $message = "Um link de redefinição foi enviado para o seu e-mail.";
                } catch (Exception $e) {
                    $message = "Não foi possível enviar o e-mail. Erro: " . $mail->ErrorInfo;
                }
            } else {
                $message = "Erro ao gerar o token de recuperação.";
            }
        } else {
            $message = "E-mail não encontrado.";
        }
    }
}
?>
<div class="row justify-content-center">
  <div class="col-md-6">
    <?php if ($message): ?>
      <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <div class="card shadow-sm">
      <div class="card-body">
        <h4 class="card-title text-center">Recuperar Senha</h4>
        <form method="post">
          <div class="mb-3">
            <label for="email" class="form-label">Informe seu E-mail:</label>
            <input type="email" class="form-control" name="email" id="email" required>
          </div>
          <button type="submit" class="btn btn-primary w-100">Recuperar Senha</button>
        </form>
      </div>
    </div>
    <div class="text-center mt-3">
      <a href="admin_login.php" class="btn btn-secondary">Voltar ao Login</a>
    </div>
  </div>
</div>
<?php require_once 'admin_footer.php'; ?>
