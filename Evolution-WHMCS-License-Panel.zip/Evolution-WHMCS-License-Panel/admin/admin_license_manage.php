<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

$pageTitle = "Gerenciar Licenças - Gestão Completa";
require_once 'admin_header.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

$message = "";

// Processamento de ações do formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $licenseId = intval($_POST['license_id'] ?? 0);

    if ($action === 'create') {
        // Criação de nova licença: gera automaticamente a chave se não for fornecida
        $licenseKey = trim($_POST['license_key'] ?? '');
        if (empty($licenseKey)) {
            $licenseKey = 'LIC-' . strtoupper(bin2hex(random_bytes(4)));
        }
        $domain = trim($_POST['domain'] ?? '');
        $ip = trim($_POST['ip'] ?? '');
        $status = $_POST['status'] ?? 'active'; // valores: active, inactive, expired, suspended
        // Converte data vazia para NULL para licenças ilimitadas
        $expiration_date = !empty($_POST['expiration_date']) ? $_POST['expiration_date'] : null;
        
        $stmt = $pdo->prepare("INSERT INTO licenses (license_key, domain, ip, status, expiration_date) VALUES (?, ?, ?, ?, ?)");
        if ($stmt->execute([$licenseKey, $domain, $ip, $status, $expiration_date])) {
            $message = "Nova licença criada com sucesso: " . htmlspecialchars($licenseKey);
            logAudit($_SESSION['admin_id'] ?? null, "Criação de Licença", "Licença criada: $licenseKey");
        } else {
            $message = "Erro ao criar a nova licença.";
        }
    } elseif ($action === 'edit') {
        // Atualiza os campos: domain, ip, status, expiration_date
        $domain = $_POST['domain'] ?? '';
        $ip = $_POST['ip'] ?? '';
        $status = $_POST['status'] ?? 'active';
        $expiration_date = !empty($_POST['expiration_date']) ? $_POST['expiration_date'] : null;
        $stmt = $pdo->prepare("UPDATE licenses SET domain = ?, ip = ?, status = ?, expiration_date = ? WHERE id = ?");
        if ($stmt->execute([$domain, $ip, $status, $expiration_date, $licenseId])) {
            $message = "Licença atualizada com sucesso.";
            logAudit($_SESSION['admin_id'] ?? null, "Edição de Licença", "Licença atualizada: ID " . $licenseId);
        } else {
            $message = "Erro ao atualizar a licença.";
        }
    } elseif ($action === 'renew') {
        // Renovação: adicionar dias à data de expiração
        $renewDays = intval($_POST['renew_days'] ?? 0);
        if ($renewDays > 0) {
            $stmt = $pdo->prepare("SELECT expiration_date FROM licenses WHERE id = ?");
            $stmt->execute([$licenseId]);
            $current = $stmt->fetch(PDO::FETCH_ASSOC);
            $currentDate = $current['expiration_date'] ? new DateTime($current['expiration_date']) : new DateTime();
            $currentDate->modify("+{$renewDays} days");
            $newExpiration = $currentDate->format('Y-m-d');
            $stmt = $pdo->prepare("UPDATE licenses SET expiration_date = ? WHERE id = ?");
            if ($stmt->execute([$newExpiration, $licenseId])) {
                $message = "Licença renovada. Nova data de expiração: " . $newExpiration;
                logAudit($_SESSION['admin_id'] ?? null, "Renovação de Licença", "Licença ID $licenseId renovada por $renewDays dias.");
            } else {
                $message = "Erro ao renovar a licença.";
            }
        } else {
            $message = "Informe um número de dias válido para renovação.";
        }
    } elseif ($action === 'reset') {
        // Reset: limpa os campos domain e ip
        $stmt = $pdo->prepare("UPDATE licenses SET domain = '', ip = '' WHERE id = ?");
        if ($stmt->execute([$licenseId])) {
            $message = "Licença resetada com sucesso.";
            logAudit($_SESSION['admin_id'] ?? null, "Reset de Licença", "Licença ID $licenseId resetada.");
        } else {
            $message = "Erro ao resetar a licença.";
        }
    } elseif ($action === 'delete') {
        // Exclusão: deleta a licença do banco
        $stmt = $pdo->prepare("DELETE FROM licenses WHERE id = ?");
        if ($stmt->execute([$licenseId])) {
            $message = "Licença excluída com sucesso.";
            logAudit($_SESSION['admin_id'] ?? null, "Exclusão de Licença", "Licença excluída: ID " . $licenseId);
        } else {
            $message = "Erro ao excluir a licença.";
        }
    }
}

// Recupera todas as licenças
$stmt = $pdo->query("SELECT * FROM licenses ORDER BY created_at DESC");
$licenses = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="container">
  <h3 class="mb-4">Gestão Completa de Licenças</h3>
  
  <?php if ($message): ?>
    <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
  <?php endif; ?>

  <!-- Botão para criar nova licença -->
  <div class="mb-4">
    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createModal">Criar Nova Licença</button>
  </div>

  <?php if (!$licenses): ?>
    <div class="alert alert-info">Nenhuma licença encontrada.</div>
  <?php else: ?>
    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead class="table-light">
          <tr>
            <th>ID</th>
            <th>Chave</th>
            <th>Domínio</th>
            <th>IP</th>
            <th>Status</th>
            <th>Expiração</th>
            <th>Criado em</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($licenses as $lic): ?>
            <tr>
              <td><?= htmlspecialchars($lic['id']); ?></td>
              <td><?= htmlspecialchars($lic['license_key']); ?></td>
              <td><?= htmlspecialchars($lic['domain']); ?></td>
              <td><?= htmlspecialchars($lic['ip']); ?></td>
              <td><?= htmlspecialchars($lic['status']); ?></td>
              <td><?= htmlspecialchars($lic['expiration_date'] ?? 'N/A'); ?></td>
              <td><?= htmlspecialchars($lic['created_at']); ?></td>
              <td>
                <!-- Botões para Editar, Renovar, Resetar e Excluir -->
                <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editModal"
                  data-id="<?= $lic['id']; ?>"
                  data-domain="<?= htmlspecialchars($lic['domain']); ?>"
                  data-ip="<?= htmlspecialchars($lic['ip']); ?>"
                  data-status="<?= htmlspecialchars($lic['status']); ?>"
                  data-expiration="<?= htmlspecialchars($lic['expiration_date']); ?>">Editar</button>
                <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#renewModal"
                  data-id="<?= $lic['id']; ?>">Renovar</button>
                <form method="post" style="display:inline-block;">
                  <input type="hidden" name="license_id" value="<?= $lic['id']; ?>">
                  <input type="hidden" name="action" value="reset">
                  <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Confirma resetar esta licença?')">Resetar</button>
                </form>
                <form method="post" style="display:inline-block; margin-left:5px;">
                  <input type="hidden" name="license_id" value="<?= $lic['id']; ?>">
                  <input type="hidden" name="action" value="delete">
                  <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Confirma excluir esta licença?')">Excluir</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
  <a href="admin_dashboard.php" class="btn btn-secondary mt-3">Voltar ao Dashboard</a>
</div>

<!-- Modal de Criação de Nova Licença -->
<div class="modal fade" id="createModal" tabindex="-1" aria-labelledby="createModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="createModalLabel">Criar Nova Licença</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="action" value="create">
        <div class="mb-3">
          <label for="license_key" class="form-label">Chave da Licença</label>
          <input type="text" class="form-control" name="license_key" id="license_key" placeholder="Deixe em branco para gerar automaticamente">
        </div>
        <div class="mb-3">
          <label for="domain" class="form-label">Domínio</label>
          <input type="text" class="form-control" name="domain" id="domain" placeholder="ex.: dev.seudominio.com">
        </div>
        <div class="mb-3">
          <label for="ip" class="form-label">IP</label>
          <input type="text" class="form-control" name="ip" id="ip" placeholder="ex.: 192.168.1.1">
        </div>
        <div class="mb-3">
          <label for="status" class="form-label">Status</label>
          <select class="form-select" name="status" id="status">
            <option value="active" selected>Ativa</option>
            <option value="inactive">Desativada</option>
          </select>
        </div>
        <div class="mb-3">
          <label for="expiration_date" class="form-label">Data de Expiração</label>
          <input type="date" class="form-control" name="expiration_date" id="expiration_date">
          <small class="text-muted">Deixe em branco se não houver expiração.</small>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
        <button type="submit" class="btn btn-success">Criar Licença</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal de Edição -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editModalLabel">Editar Licença</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="license_id" id="edit_license_id">
        <input type="hidden" name="action" value="edit">
        <div class="mb-3">
          <label for="edit_domain" class="form-label">Domínio</label>
          <input type="text" class="form-control" name="domain" id="edit_domain">
        </div>
        <div class="mb-3">
          <label for="edit_ip" class="form-label">IP</label>
          <input type="text" class="form-control" name="ip" id="edit_ip">
        </div>
        <div class="mb-3">
          <label for="edit_status" class="form-label">Status</label>
          <select class="form-select" name="status" id="edit_status">
            <option value="active">Ativa</option>
            <option value="inactive">Desativada</option>
            <option value="expired">Expirada</option>
            <option value="suspended">Suspensa</option>
          </select>
        </div>
        <div class="mb-3">
          <label for="edit_expiration" class="form-label">Data de Expiração</label>
          <input type="date" class="form-control" name="expiration_date" id="edit_expiration">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
        <button type="submit" class="btn btn-primary">Salvar Alterações</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal de Renovação -->
<div class="modal fade" id="renewModal" tabindex="-1" aria-labelledby="renewModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="renewModalLabel">Renovar Licença</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="license_id" id="renew_license_id">
        <input type="hidden" name="action" value="renew">
        <div class="mb-3">
          <label for="renew_days" class="form-label">Dias para Renovação</label>
          <input type="number" class="form-control" name="renew_days" id="renew_days" required>
          <small class="text-muted">Informe o número de dias a serem adicionados à data de expiração atual.</small>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
        <button type="submit" class="btn btn-primary">Renovar Licença</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Preenche os dados do modal de edição
var editModal = document.getElementById('editModal');
editModal.addEventListener('show.bs.modal', function (event) {
  var button = event.relatedTarget;
  var licenseId = button.getAttribute('data-id');
  var domain = button.getAttribute('data-domain');
  var ip = button.getAttribute('data-ip');
  var status = button.getAttribute('data-status');
  var expiration = button.getAttribute('data-expiration');

  document.getElementById('edit_license_id').value = licenseId;
  document.getElementById('edit_domain').value = domain;
  document.getElementById('edit_ip').value = ip;
  document.getElementById('edit_status').value = status;
  document.getElementById('edit_expiration').value = expiration;
});

// Preenche os dados do modal de renovação
var renewModal = document.getElementById('renewModal');
renewModal.addEventListener('show.bs.modal', function (event) {
  var button = event.relatedTarget;
  var licenseId = button.getAttribute('data-id');
  document.getElementById('renew_license_id').value = licenseId;
});
</script>

<?php require_once 'admin_footer.php'; ?>
