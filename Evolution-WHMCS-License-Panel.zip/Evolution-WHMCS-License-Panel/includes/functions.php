<?php
// File: includes/functions.php

/**
 * Valida se a senha atende aos critérios de complexidade.
 * Requisitos:
 * - Mínimo de 8 caracteres
 * - Pelo menos uma letra maiúscula
 * - Pelo menos uma letra minúscula
 * - Pelo menos um número
 * - Pelo menos um caractere especial
 *
 * @param string $password
 * @return bool|string Retorna true se a senha é válida ou uma mensagem de erro se não for.
 */
function isPasswordComplex($password) {
    if (strlen($password) < 8) {
        return "A senha deve ter no mínimo 8 caracteres.";
    }
    if (!preg_match('/[A-Z]/', $password)) {
        return "A senha deve conter pelo menos uma letra maiúscula.";
    }
    if (!preg_match('/[a-z]/', $password)) {
        return "A senha deve conter pelo menos uma letra minúscula.";
    }
    if (!preg_match('/[0-9]/', $password)) {
        return "A senha deve conter pelo menos um número.";
    }
    if (!preg_match('/[\W_]/', $password)) {
        return "A senha deve conter pelo menos um caractere especial.";
    }
    return true;
}

/**
 * Registra um log de auditoria.
 *
 * @param int|null $adminId O ID do administrador que realizou a ação (pode ser nulo)
 * @param string $action Descrição breve da ação
 * @param string|null $details Detalhes adicionais (opcional)
 */
function logAudit($adminId, $action, $details = null) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO audit_logs (admin_id, action, details) VALUES (?, ?, ?)");
    $stmt->execute([$adminId, $action, $details]);
}

/**
 * Retorna o valor de uma configuração específica do sistema.
 *
 * @param string $key
 * @return string|null
 */
function getConfigValue($key) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT config_value FROM configurations WHERE config_key = ? LIMIT 1");
    $stmt->execute([$key]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ? $row['config_value'] : null;
}

/**
 * Retorna um array de valores de configurações para as chaves especificadas.
 *
 * @param array $keys
 * @return array Associativo com chave => valor
 */
function getConfigValues(array $keys) {
    global $pdo;
    $placeholders = str_repeat('?,', count($keys) - 1) . '?';
    $stmt = $pdo->prepare("SELECT config_key, config_value FROM configurations WHERE config_key IN ($placeholders)");
    $stmt->execute($keys);
    $rows = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
    // Assegura que todas as chaves requisitadas estão no array (mesmo que com null)
    $result = [];
    foreach ($keys as $key) {
        $result[$key] = isset($rows[$key]) ? $rows[$key] : null;
    }
    return $result;
}
